//Base do Bot desenvolvido Pelo Criador Daniel Dev </> todos os créditos para o Daniel Dev </>
import fs from "fs";
import { Client, GatewayIntentBits } from "discord.js";

// ========[ CONFIGURAÇÕES ]======== //
const config = JSON.parse(fs.readFileSync("./config/config.json", "utf-8"));
const { token, prefix, NomeDoBot, NickDono } = config;

// ========[ CLIENT ]======== //
const client = new Client({
intents: [ GatewayIntentBits.Guilds GatewayIntentBits.GuildMessages,GatewayIntentBits.MessageContent ]
});

// ========[ MSG QUANDO O BOT LIGA ]======== //
client.once("clientReady", () => {
console.log(`✅ ${NomeDoBot} está online como ${client.user.tag}`);
client.user.setActivity(`${NomeDoBot}`, { type: 0 });
});

// ======[ COMANDOS ] ====== //
client.on("messageCreate", async (msg) => {
if (msg.author.bot || !msg.content
startsWith(prefix)) return;
const args = msg.content.slice(prefix.length)
trim().split(/ +/);
const comando = args.shift().toLowerCase();
switch (comando) {

case "ping":
msg.reply("🏓 Pong!");
break;

case "dono":
msg.reply(`👑 Meu dono é ${NickDono}`);
break;

default:
msg.reply("Esse comando não existe ksksksks");
break;
}
});

// ========[ LOGIN ]======== //
client.login(token)
.then(() => console.log("O Bot foi Conectado com sucesso"))
.catch((err) => console.error("Humm Deu um pequeno erro ao conectar com o Bot", err));