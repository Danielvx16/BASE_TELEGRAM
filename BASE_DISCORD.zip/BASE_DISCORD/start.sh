#!/bin/bash
while true
do
clear
printf "Iniciando a base, aguarde um momento..."
node index.js
sleep 2
printf "A Base foi finalizado. Reiniciando..."
sleep 2
done