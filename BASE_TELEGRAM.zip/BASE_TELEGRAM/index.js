//Base do Bot desenvolvido Pelo Criador Daniel Dev </> todos os créditos para o Daniel Dev </>
// ====== [ MÓDULOS ]====== //
const fs = require("fs");
const { Telegraf } = require("telegraf");
// ======[ CONFIGURAÇÕES ]====== //
const configPath = "./dono/config.json";
if (!fs.existsSync(configPath)) {
console.log("⚠️  Arquivo de configuração não encontrado (dono/config.json)");
process.exit(1);
}
const config = JSON.parse(fs.readFileSync(configPath, "utf8"));
const { token, prefix, NomeDoBot, NickDono } = config;
// ======[ INICIALIZAÇÃO DO BOT] ====== //
const bot = new Telegraf(token);
async function enviar(ctx, msg) {
try {
return await ctx.reply(msg);
} catch (err) {
console.log("Erro ao enviar mensagem:", err.message);
}
}
// ======[ SISTEMA DE COMANDOS ]====== //
bot.on("text", async (ctx) => {
const texto = ctx.message.text;
if (!texto.startsWith(prefix)) return;
const args = texto.slice(prefix.length).trim().split(/ +/);
const comando = args.shift().toLowerCase();
try {
switch (comando) {
   
case "start":
await enviar(ctx, "E aí bem vindo a base");
break;
default:

await enviar(ctx, "Esse comado não existe ksksksksks");
break;
}
} catch (err) {
console.log("Ixi deu um erro ao processar essa bomba de comando", err.message);
await enviar(ctx, "Foi mal aí aconteceu um erro aí executar o comando kkkk");
}
});
// ======[ INICIALIZAÇÃO ]====== //
bot.launch().then(() => {
console.log(`${NomeDoBot} está ligado com sucesso hehehehe`);
console.log(`👑 Dono: ${NickDono}`);
console.log(`💬 Prefixo: ${prefix}`);
});